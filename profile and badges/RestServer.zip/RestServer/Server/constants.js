
module.exports = {
	"baseFolder":"./public/CoverageReport/",
	"staticResourcePath":"./public/CoverageReportResources",
	"reporterFile": "./public/CoverageReportJson/report.json"
}